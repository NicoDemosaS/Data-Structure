#ifndef STRUCTS_H
#define STRUCTS_H

struct noh{
    void*  info;
    pNoh   prox;
};

struct dLista{
    pNoh inicio;
    pNoh fim;
    int quantidade;
};


#endif



