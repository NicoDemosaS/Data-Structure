#include "TAD_ListaLinear.h"

#include "Operacoes/0_structs.h"

#include "Operacoes/1_criarLista.h"

#include "Operacoes/2_incluirInfo.h"

#include "Operacoes/3_excluirInfo.h"

#include "Operacoes/4_contemInfo.h"

#include "Operacoes/5_imprimirLista.h"

#include "Operacoes/6_destruirLista.h"

#include "Operacoes/7_duplicarLista.h"

#include "Operacoes/8_dividirLista.h"

#include "Operacoes/9_buscarNohInfo.h"
