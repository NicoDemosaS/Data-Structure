#ifndef STRUCT_DESCRITOR_ARVORE_H
#define STRUCT_DESCRITOR_ARVORE_H

struct dArvore{
    pNohArvore raiz;
    int        quantidadeNohs;
    int        grau;
};


#endif
