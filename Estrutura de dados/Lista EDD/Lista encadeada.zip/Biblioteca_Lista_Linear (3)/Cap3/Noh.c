struct noh{
   void *info;
   struct noh   *prox;
};
