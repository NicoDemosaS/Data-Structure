#ifndef CALCULAR_MEDIA_H
#define CALCULAR_MEDIA_H


float calcularMedia (pDLista lista, FuncaoMapeamento fm)
{
}

#endif