#ifndef STRUCTS_PILHA_H
#define STRUCTS_PILHA_H

/* ------------------------------- */
struct dPilha{
    pDLista pdLista;
};

#endif
